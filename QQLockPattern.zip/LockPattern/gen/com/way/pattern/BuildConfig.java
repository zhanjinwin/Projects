/** Automatically generated file. DO NOT MODIFY */
package com.way.pattern;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}